# Import necessary classes and modules
from Graph import Graph_journey_duration  # Importing Graph_journey_duration class from Graph module
from mst import kruskal  # Import the Kruskal's algorithm for minimum spanning tree
import os
# Define a class for analyzing closures in the transportation network
class ClosureAnalysis:
    # Constructor for the class that takes a graph object as an argument
    def __init__(self, graph):
        self.graph = graph  # Store the graph object for later use
        self.removable_edges = set()  # Set to store edges that can be removed
        self.edges_by_line = {}  # Dictionary to store removable edges by line
        self.operation_count = 0  # Initialize operation count
    # Method to advise which connections (edges) can be closed
    
    def advise_closures(self):
        mst = kruskal(self.graph.graph)  # Apply Kruskal's algorithm to find the minimum spanning tree
        self.operation_count = 0  # Reset operation count at the beginning
        # Iterate through all edges in the graph
        for edge in self.graph.graph.get_edge_list():
            self.operation_count += 1  # Increment operation count
            station1, station2 = edge
            # Check if the edge is not in the minimum spanning tree
            if not mst.has_edge(station1, station2) and not mst.has_edge(station2, station1):
                ordered_edge = (min(station1, station2), max(station1, station2))
                self.removable_edges.add(ordered_edge)  # Add the removable edge
                line_name = self.graph.tube_lines.get((station1, station2)) or self.graph.tube_lines.get((station2, station1))
                self.edges_by_line.setdefault(line_name, []).append(ordered_edge)  # Group removable edges by line
          
        # Sort the removable edges within each line
        for line in self.edges_by_line:
            self.edges_by_line[line].sort(key=lambda edge: (self.graph.int_to_station[edge[0]], self.graph.int_to_station[edge[1]]))
        print(f"Analysis took {self.operation_count} operations.")  # Print the time taken for the analysis
        return self.removable_edges, self.edges_by_line

# Define a class to report potential closures
class ClosureReport:
    # Constructor for the class
    def __init__(self, edges_by_line, graph):
        self.edges_by_line = edges_by_line  # Removable edges grouped by line
        self.graph = graph  # Graph object

    # Method to report potential removal options
    def report_removal_options(self):
        # Check if there are no removable edges
        if not self.edges_by_line:
            print("No edges can be removed while keeping the network connected.")
            return

        # Report removable edges by line
        print("\nAnalysis of potential tube line closures:")
        for line, edges in self.edges_by_line.items():
            print(f"\n{line} line can have the following connections removed:")
            for station1, station2 in edges:
                print(f"{self.graph.int_to_station[station1]} -- {self.graph.int_to_station[station2]}")

# Define a class to export closure data to Excel
class ClosureExport:
    # Constructor for the class
    def __init__(self, removable_edges, graph):
        self.removable_edges = removable_edges  # Set of removable edges
        self.graph = graph  # Graph object

    # Method to export closures to an Excel file
    def export_closures_to_excel(self, file_path):
        # Prepare tuples of removable edge station names
        removable_edges_tuples = [(self.graph.int_to_station[station1], self.graph.int_to_station[station2]) for station1, station2 in self.removable_edges]

        # Copy the original data and filter out the removable edges
        filtered_db = self.graph.db.copy()
        for edge_tuple in removable_edges_tuples:
            # Filter out both directions of each removable edge
            filtered_db = filtered_db[~((filtered_db['station 1'] == edge_tuple[0]) & (filtered_db['station 2'] == edge_tuple[1]))]
            filtered_db = filtered_db[~((filtered_db['station 2'] == edge_tuple[0]) & (filtered_db['station 1'] == edge_tuple[1]))]

        # Save the filtered data to Excel
        filtered_db.to_excel(file_path, index=False)
        print("\nFiltered data saved to: \n" + file_path)
        
# Main execution block
if __name__ == "__main__":

    current_dir = os.path.dirname(__file__)
    parent_dir = os.path.dirname(current_dir)
    # Path to the Excel file containing the London Underground data
    data_file_path = os.path.join(parent_dir, r"Data sets\London Underground data with times only.xlsx")

    # Path for output file after applying closures
    output_file_path = os.path.join(parent_dir, r"Data sets\duration minutes\London_Underground_Data_After_Closure_journey_duration.xlsx")
    
    # Initialize the graph
    graph = Graph_journey_duration(data_file_path)

    # Perform closure analysis
    closure_analysis = ClosureAnalysis(graph)
    removable_edges, edges_by_line = closure_analysis.advise_closures()

    # Report potential closures
    closure_report = ClosureReport(edges_by_line, graph)
    closure_report.report_removal_options()

    # Export the closures to Excel
    closure_export = ClosureExport(removable_edges, graph)
    closure_export.export_closures_to_excel(output_file_path)

