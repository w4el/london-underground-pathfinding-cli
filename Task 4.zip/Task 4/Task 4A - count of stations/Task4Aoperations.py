# Import necessary classes and modules
from Graph import Graph_count_stations  # Importing the Graph class tailored for counting stations
from mst import kruskal  # Importing Kruskal's algorithm for minimum spanning tree (MST) calculation
import os
# Define a class for analyzing potential closures in a transport network
class ClosureAnalysis:
    # Constructor for the class that takes a graph object as an argument
    def __init__(self, graph):
        self.graph = graph  # Store the graph object for later use
        self.removable_edges = set()  # Set to store edges that can be removed without disconnecting the network
        self.edges_by_line = {}  # Dictionary to store removable edges grouped by the tube line
        self.operation_count = 0
    # Method to advise which connections (edges) can be safely closed
    def advise_closures(self):
        mst = kruskal(self.graph.graph)  # Compute the minimum spanning tree using Kruskal's algorithm
        self.operation_count = 0  # Reset operation count at the beginning
        # Iterate through all edges in the graph
        for edge in self.graph.graph.get_edge_list():
            self.operation_count += 1
            if len(edge) == 3:  # if the edge is a tuple like (station1, station2, weight)
                station1, station2, _ = edge
            else:  # if the edge is a tuple like (station1, station2)
                station1, station2 = edge

            # Check if the edge is not part of the minimum spanning tree
            if not mst.has_edge(station1, station2) and not mst.has_edge(station2, station1):
                ordered_edge = (min(station1, station2), max(station1, station2))  # Order the edge for consistency
                self.removable_edges.add(ordered_edge)  # Add the edge to the set of removable edges
                # Determine the tube line of the edge and group the edge accordingly
                line_name = self.graph.tube_lines.get((station1, station2)) or self.graph.tube_lines.get((station2, station1))
                self.edges_by_line.setdefault(line_name, []).append(ordered_edge)

        # Sort the removable edges within each tube line for readability
        for line in self.edges_by_line:
            self.edges_by_line[line].sort(key=lambda edge: (self.graph.int_to_station[edge[0]], self.graph.int_to_station[edge[1]]))
        print(f"Analysis took {self.operation_count} operations.")
        return self.removable_edges, self.edges_by_line  # Return the removable edges and the grouped edges by line
# Define a class for reporting potential closures based on the analysis
class ClosureReport:
    # Constructor for the class
    def __init__(self, edges_by_line, graph):
        self.edges_by_line = edges_by_line  # Store the edges grouped by line
        self.graph = graph  # Store the graph object

    # Method to report potential closure options
    def report_removal_options(self):
        if not self.edges_by_line:
            print("No edges can be removed while keeping the network connected.")
            return

        # Report the potential closures line by line
        print("\nAnalysis of potential tube line closures:")
        for line, edges in self.edges_by_line.items():
            print(f"\n{line} line can have the following connections removed:")
            for station1, station2 in edges:
                print(f"{self.graph.int_to_station[station1]} -- {self.graph.int_to_station[station2]}")

# Define a class to export the closure data to Excel
class ClosureExport:
    # Constructor for the class
    def __init__(self, removable_edges, graph):
        self.removable_edges = removable_edges  # Store the set of removable edges
        self.graph = graph  # Store the graph object

    # Method to export closure data to an Excel file
    def export_closures_to_excel(self, file_path):
        # Prepare a list of tuples for the removable edges
        removable_edges_tuples = [(self.graph.int_to_station[station1], self.graph.int_to_station[station2]) for station1, station2 in self.removable_edges]

        # Copy the graph's data and filter out the removable edges
        filtered_db = self.graph.db.copy()
        for edge_tuple in removable_edges_tuples:
            filtered_db = filtered_db[~((filtered_db['station 1'] == edge_tuple[0]) & (filtered_db['station 2'] == edge_tuple[1]))]
            filtered_db = filtered_db[~((filtered_db['station 2'] == edge_tuple[0]) & (filtered_db['station 1'] == edge_tuple[1]))]

        # Export the filtered data to Excel
        filtered_db.to_excel(file_path, index=False)
        print("\nFiltered data saved to: \n" + file_path)
        
# Main execution block
if __name__ == "__main__":
    current_dir = os.path.dirname(__file__)
    parent_dir = os.path.dirname(current_dir)
    # Define the path to the Excel file containing the London Underground data
    data_file_path = os.path.join(parent_dir, r"Data sets\London Underground data with times only.xlsx")

    # Define the output file path for the data after applying closures
    output_file_path = os.path.join(parent_dir, r"Data sets\station count\London_Underground_Data_After_Closure_Count_Of_Stations.xlsx")
    
    # Initialize the graph using the provided data
    graph = Graph_count_stations(data_file_path)

    # Perform closure analysis to identify removable edges
    closure_analysis = ClosureAnalysis(graph)
    removable_edges, edges_by_line = closure_analysis.advise_closures()

    # Generate a report on potential closures
    closure_report = ClosureReport(edges_by_line, graph)
    closure_report.report_removal_options()

    # Export the analyzed closure data to an Excel file
    closure_export = ClosureExport(removable_edges, graph)
    closure_export.export_closures_to_excel(output_file_path)

    # This script conducts an analysis to determine which edges (connections between stations) can be removed 
    # from a transport network without disrupting the overall connectivity. It leverages Kruskal's algorithm to 
    # find a minimum spanning tree, identifying edges not in this tree as removable. The results are then reported 
    # and exported to Excel, providing insights into potential network optimization or closure strategies.
